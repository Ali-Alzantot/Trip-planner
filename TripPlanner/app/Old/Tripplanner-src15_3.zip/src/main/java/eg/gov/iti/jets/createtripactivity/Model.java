package eg.gov.iti.jets.createtripactivity;

import android.content.Context;
import android.os.AsyncTask;

import eg.gov.iti.jets.createtripactivity.interfaces.ModelInterface;
import eg.gov.iti.jets.databasepkg.DatabaseAdapter;
import eg.gov.iti.jets.dtos.Trip;

/**
 * Created by esraa on 3/5/2018.
 */

public class Model implements ModelInterface {

    Context context;
    DatabaseAdapter databaseAdapter;

    public Model(Context context) {
        this.context = context;
        databaseAdapter = new DatabaseAdapter(context);
    }

    @Override
    public Trip addTrip(Trip trip) {
        return  databaseAdapter.addTrip(trip);

    }

    @Override
    public void updateTrip(Trip trip) {
        new UpdateTripTask().execute(trip);
    }




    private class UpdateTripTask extends AsyncTask<Trip, Void, Void> {


        @Override
        protected Void doInBackground(Trip... trips) {
            databaseAdapter.updateTrip(trips[0]);
            return null;
        }
    }

}
