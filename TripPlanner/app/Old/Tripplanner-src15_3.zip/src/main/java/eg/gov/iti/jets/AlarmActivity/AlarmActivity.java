package eg.gov.iti.jets.AlarmActivity;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import eg.gov.iti.jets.AlarmActivity.alarminterfaces.ViewInterface;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.tripplanner.R;

public class AlarmActivity extends AppCompatActivity implements ViewInterface {
    private Trip trip;
    private ImageView tripPhoto;
    private TextView tripName, startPoint, endPoint, schedule;
    private Button startBtn, laterBtn, cancelBtn;
    private boolean buttonPressedFlag;
    private MediaPlayer alarmTonePlayer;
    private Vibrator vibrator;
    private String fromNotification;
    private AlarmPresenter alarmPresenter;
    private Integer userID, tripID;
    private int origionalVolume;
    private AudioManager audioManger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD_DIALOG);
        super.onCreate(savedInstanceState);
        ActivityManager activityManager = (ActivityManager) getApplicationContext()
                .getSystemService(Context.ACTIVITY_SERVICE);
        activityManager.moveTaskToFront(getTaskId(), 0);
        setContentView(R.layout.activity_alarm);
        buttonPressedFlag = false;

        alarmPresenter = new AlarmPresenter(this);
        alarmPresenter.setView(this);
        this.setFinishOnTouchOutside(false);
        userID = getIntent().getIntExtra("user_id", -1);
        tripID = getIntent().getIntExtra("trip_id", -1);
        fromNotification = getIntent().getStringExtra("Notification");

        if (getIntent().getStringExtra("cancel") != null) {
            if (userID != -1 && tripID != -1) {
                trip = alarmPresenter.getTripInstantly(userID, tripID);
                trip.setStatus(Trip.CANCELLED);
                alarmPresenter.updateTripInDB(trip);
                finish();
            }
        } else if (getIntent().getStringExtra("start") != null) {
            trip = alarmPresenter.getTripInstantly(userID, tripID);
            trip.setStatus(Trip.ONGOING);
            alarmPresenter.updateTripInDB(trip);
            showDirections();
        }

        if (userID != -1 && tripID != -1) {
            alarmPresenter.getTripFromDB(userID, tripID);
            if (fromNotification != null) {
                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.cancel(Integer.parseInt(userID.toString() + tripID.toString()));
            }
        }
        tripPhoto = (ImageView) findViewById(R.id.alarm_trip_photo);
        tripName = (TextView) findViewById(R.id.alarm_trip_title);
        startPoint = (TextView) findViewById(R.id.alarm_start_point);
        endPoint = (TextView) findViewById(R.id.alarm_end_point);
        schedule = (TextView) findViewById(R.id.alarm_date_time);
        startBtn = (Button) findViewById(R.id.alarm_start_btn);
        laterBtn = (Button) findViewById(R.id.alarm_later_btn);
        cancelBtn = (Button) findViewById(R.id.alarm_cancel_btn);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);


        if (userID != -1 && tripID != -1) {
            alarmPresenter.getTripInstantly(userID, tripID);
            if (fromNotification != null) {
                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.cancel(Integer.parseInt(userID.toString() + tripID.toString()));
            }
        }
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonPressedSuccessfully();
                if (trip != null) {
                    trip.setStatus(Trip.ONGOING);
                    alarmPresenter.updateTripInDB(trip);
                    showDirections();
                }
            }
        });
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonPressedSuccessfully();
                if (trip != null) {
                    trip.setStatus(Trip.CANCELLED);
                    alarmPresenter.updateTripInDB(trip);
                    finish();
                }
            }
        });
        laterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonPressedSuccessfully();
                if (trip != null) {
                    // content intent
                    Intent alarmIntent = new Intent(AlarmActivity.this, AlarmActivity.class);
                    alarmIntent.putExtra("user_id", trip.getUserId());
                    alarmIntent.putExtra("trip_id", trip.getTripId());
                    alarmIntent.putExtra("Notification", "notify");
                    PendingIntent alarmPendingIntent = PendingIntent.getActivity(AlarmActivity.this, Integer.parseInt(trip.getUserId().toString() + trip.getTripId().toString() + "1"), alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    // cancel intent
                    Intent cancelIntent = new Intent(AlarmActivity.this, AlarmActivity.class);
                    alarmIntent.putExtra("user_id", trip.getUserId());
                    alarmIntent.putExtra("trip_id", trip.getTripId());
                    alarmIntent.putExtra("cancel", "cancel");
                    PendingIntent cancelPendingIntent = PendingIntent.getActivity(AlarmActivity.this, Integer.parseInt(trip.getUserId().toString() + trip.getTripId().toString() + "2"), alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    // start intent
                    Intent startIntent = new Intent(AlarmActivity.this, AlarmActivity.class);
                    alarmIntent.putExtra("user_id", trip.getUserId());
                    alarmIntent.putExtra("trip_id", trip.getTripId());
                    alarmIntent.putExtra("start", "start");
                    PendingIntent startPendingIntent = PendingIntent.getActivity(AlarmActivity.this, Integer.parseInt(trip.getUserId().toString() + trip.getTripId().toString() + "3"), alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);


                    NotificationCompat.Builder mBuilder =
                            new NotificationCompat.Builder(AlarmActivity.this)
                                    .setOngoing(true)
                                    .setWhen(System.currentTimeMillis())
                                    .setSmallIcon(R.drawable.go)
                                    .setTicker("Trip Alarm")
                                    .setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_SOUND)
                                    .setContentInfo("Info")
                                    .setContentTitle("New Trip on hold")
                                    .setStyle(new NotificationCompat.BigTextStyle())
                                    .setLights(Color.BLUE, 500, 500)
                                    .setContentText(trip.getTripName() + " waiting to start ")
                                    .setPriority(NotificationCompat.PRIORITY_MAX)
                                    .setContentIntent(alarmPendingIntent)
                                    .addAction(R.drawable.cross, "Cancel", cancelPendingIntent)
                                    .addAction(R.drawable.place_holder, "Start", startPendingIntent);
                    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    notificationManager.notify(Integer.parseInt(trip.getUserId().toString() + trip.getTripId().toString()), mBuilder.build());
                    finish();

                }

            }
        });


    }

    private void showDirections() {
        Uri gmmIntentUri = Uri.parse("google.navigation:q=" + trip.getEndLatitude() + "," + trip.getEndLongitude() + "&travelmode=driving");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        if (mapIntent.resolveActivity(AlarmActivity.this.getPackageManager()) != null) {
            startActivity(mapIntent);
            finish();
        } else {
            Toast.makeText(AlarmActivity.this, "Please install a maps application", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (!buttonPressedFlag) {
            ActivityManager activityManager = (ActivityManager) getApplicationContext()
                    .getSystemService(Context.ACTIVITY_SERVICE);
            activityManager.moveTaskToFront(getTaskId(), 0);
        } else {
            stopSound();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        return false;
    }

    @Override
    public void addTripToView(final Trip trip) {
        if (trip != null) {
            this.trip = trip;
            if (fromNotification == null) {
                startSound();
            }

            if (trip.getPhoto() != null && !trip.getPhoto().trim().equals("")) {
                if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                    File file = new File(trip.getPhoto());
                    if (file.exists()) {
                        new RetreiveImage().execute(file);
                    }
                }
            }
            tripName.setText(trip.getTripName());
            startPoint.setText(trip.getStartPoint());
            endPoint.setText(trip.getEndPoint());
            schedule.setText(trip.getStartDate() + "  At  " + trip.getStartTime());
        }
    }

    private void buttonPressedSuccessfully() {
        buttonPressedFlag = true;
        stopSound();
    }

    private void startSound() {
        if (fromNotification == null) {

            Uri uri = Uri.parse("android.resource://" + getPackageName() + "/raw/alarm");
            audioManger = (AudioManager) getSystemService(AUDIO_SERVICE);
            origionalVolume = audioManger.getStreamVolume(AudioManager.STREAM_ALARM);
            audioManger.setStreamVolume(AudioManager.STREAM_ALARM, audioManger.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
            alarmTonePlayer = new MediaPlayer();
            try {
                alarmTonePlayer.setDataSource(AlarmActivity.this.getApplicationContext(), uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            alarmTonePlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
            alarmTonePlayer.setLooping(true);
            alarmTonePlayer.prepareAsync();
            alarmTonePlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.start();
                }
            });
            long[] pattern = {0, 100, 1000};
            vibrator.vibrate(pattern, 0);
        }
    }

    private void stopSound() {
        if (alarmTonePlayer != null) {
            alarmTonePlayer.stop();
            alarmTonePlayer.release();
            alarmTonePlayer = null;
        }
        if (audioManger != null) {
            audioManger.setStreamVolume(AudioManager.STREAM_ALARM, origionalVolume, 0);
        }
        if (vibrator != null) {
            vibrator.cancel();
        }
    }


    private class RetreiveImage extends AsyncTask<File, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(File... files) {
            Bitmap photo = null;
            try (FileInputStream fis = new FileInputStream(files[0])) {
                photo = BitmapFactory.decodeStream(fis);
            } catch (IOException ex) {
                Toast.makeText(AlarmActivity.this, "Something went wrong retreive image", Toast.LENGTH_SHORT);
            }
            return photo;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if (bitmap != null) {
                tripPhoto.setImageBitmap(bitmap);
            }
        }
    }
}