package eg.gov.iti.jets.upcomingtripsfragment;

import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

import eg.gov.iti.jets.databasepkg.DatabaseAdapter;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.dtos.User;
import eg.gov.iti.jets.upcomingtripsfragment.upcomingfragmentinterfaces.ModelInterface;
import eg.gov.iti.jets.upcomingtripsfragment.upcomingfragmentinterfaces.PresenterInterface;

/**
 * Created by Usama on 7/3/2018.
 */

public class UpcomingModel implements ModelInterface {
    private PresenterInterface presenter;
    private DatabaseAdapter dbAdapter;


    public UpcomingModel(Context context, PresenterInterface upcommingPresenter) {
        dbAdapter = new DatabaseAdapter(context);
        presenter = upcommingPresenter;
    }

    @Override
    public void getAllTrips() {
        new getAllTripsTask().execute(User.getUser());
    }

    @Override
    public void deleteTrip(Trip trip) {
        new deleteTripTask().execute(trip);
    }

    @Override
    public void updateTrip(Trip trip) {
        new updateTripTask().execute(trip);
    }


    private class getAllTripsTask extends AsyncTask<User, Void, List<Trip>> {
        @Override
        protected List<Trip> doInBackground(User... users) {
            return dbAdapter.getAllUpcomingTrips(users[0]);
        }

        @Override
        protected void onPostExecute(List<Trip> trips) {
            if (trips != null) {
                presenter.addTripListToView(trips);
            }
        }
    }

    private class deleteTripTask extends AsyncTask<Trip, Void, Trip> {

        @Override
        protected Trip doInBackground(Trip... trips) {
            dbAdapter.deleteTrip(trips[0]);
            return trips[0];
        }

        @Override
        protected void onPostExecute(Trip trip) {
            presenter.deleteTripFromView(trip);
        }
    }

    private class updateTripTask extends AsyncTask<Trip, Void, Trip> {

        @Override
        protected Trip doInBackground(Trip... trips) {
            dbAdapter.updateTrip(trips[0]);
            return trips[0];
        }

        @Override
        protected void onPostExecute(Trip trip) {
            presenter.updateTripInView(trip);
        }
    }
}
