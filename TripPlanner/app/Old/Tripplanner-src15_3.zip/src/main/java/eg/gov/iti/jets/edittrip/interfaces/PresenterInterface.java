package eg.gov.iti.jets.edittrip.interfaces;

import eg.gov.iti.jets.dtos.Trip;

/**
 * Created by esraa on 3/5/2018.
 */

public interface PresenterInterface {

    public void updateTrip(Trip trip);
}
