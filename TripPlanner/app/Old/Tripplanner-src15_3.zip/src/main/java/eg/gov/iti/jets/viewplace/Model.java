package eg.gov.iti.jets.viewplace;

import eg.gov.iti.jets.viewplace.interfaces.ModelInterface;

/**
 * Created by esraa on 3/5/2018.
 */

public class Model implements ModelInterface {
}
