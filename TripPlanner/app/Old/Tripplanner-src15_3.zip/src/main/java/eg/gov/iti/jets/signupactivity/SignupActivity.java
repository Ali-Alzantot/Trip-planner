package eg.gov.iti.jets.signupactivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;

import eg.gov.iti.jets.databasepkg.DatabaseAdapter;
import eg.gov.iti.jets.databasepkg.FirebaseDatabaseDAO;
import eg.gov.iti.jets.databasepkg.MyCallback;
import eg.gov.iti.jets.dtos.User;

import eg.gov.iti.jets.profileactivity.Profile;
import eg.gov.iti.jets.tripplanner.NavigationDrawerActivity;
import eg.gov.iti.jets.tripplanner.R;

public class SignupActivity extends AppCompatActivity implements View.OnClickListener{
    Button signUpButton;
    private Uri filePath;
    private static final int PICK_IMAGE_REQUEST = 234;
    ImageView imageView;
    Bitmap bitmap;
    EditText emailRegText,passwordRegText,userNameRegTex,passwordConfirmRegText;
    String email,password,passwordConfirm,userName;
    TextView imageRegValidation;
    boolean chkImageUpload=false;
    User userFromReg,gettenUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        signUpButton=findViewById(R.id.signUpButton);
        signUpButton.setOnClickListener(this);
        imageView=findViewById(R.id.imageRegView);
        imageView.setOnClickListener(this);
        emailRegText=findViewById(R.id.emailRegText);
        passwordRegText=findViewById(R.id.passwordRegText);
        userNameRegTex=findViewById(R.id.userNameRegText);
        passwordConfirmRegText=findViewById(R.id.passwordConfirmRegText);
        imageRegValidation=findViewById(R.id.imageRegValidation);
        imageView.setImageResource(R.mipmap.upphoto);

    }

    //method to show file chooser
    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }



    //handling the image chooser activity result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                 bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                 imageView.setImageBitmap(bitmap);
                 chkImageUpload=true;


            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }





    public void signUpMethod(){
        boolean chkError=false;
        userName=userNameRegTex.getText().toString();
        email=emailRegText.getText().toString();
        password=passwordRegText.getText().toString();
        passwordConfirm=passwordConfirmRegText.getText().toString();

        if(userName.isEmpty()){
            userNameRegTex.setError("please enter Your user Name");
            chkError=true;
        }


        if(email.isEmpty()){
            emailRegText.setError("please enter Your Email");
            chkError=true;
        }

        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            emailRegText.setError("please enter a Valid Email");
            chkError=true;
        }

        if(password.isEmpty() || password.length()<6){
            passwordRegText.setError("please enter Password not less than 6 chars");
            chkError=true;
        }

        if(!password.equals(passwordConfirm)){
            passwordConfirmRegText.setError("password dosen't match");
            chkError=true;
        }

        if(chkImageUpload==false){
            imageRegValidation.setText("Please Upload your Photo");
            chkError=true;
        }
        else{
            imageRegValidation.setText("");
        }

        if(chkError)
            return;
        else{
            userFromReg=User.getUser();
            userFromReg.setEmail(email);
            userFromReg.setPassword(password);
            userFromReg.setUserName(userName);
            userFromReg.setPhoto("dummy photo");
            new FirebaseDatabaseDAO().getMaxuserIDFromFirebase(new MyCallback() {
                @Override
                public void onMaxIdCallBack(int max) {
                    DatabaseAdapter databaseAdapter=new DatabaseAdapter(getApplicationContext());
                    max= Math.max(databaseAdapter.getNewUserId(),max);
                    userFromReg.setUserId(max+1);
                }
                @Override
                public void onGetUserCallBack(User user) {}
                @Override
                public void onGetUserByEmailCallBack(User user) {}
            });


            gettenUser=new DatabaseAdapter(getApplicationContext()).retreiveUserByEmail(userFromReg.getEmail());
            if(gettenUser==null){
                new FirebaseDatabaseDAO().getUserFromFirebaseByEmail(userFromReg.getEmail(), new MyCallback() {
                    @Override
                    public void onMaxIdCallBack(int max) {}
                    @Override
                    public void onGetUserCallBack(User user) {}
                    @Override
                    public void onGetUserByEmailCallBack(User user) {
                        gettenUser=user;
                        if(gettenUser==null){

                            //not finding user in both loacl storgae or firebase
                            new DatabaseAdapter(getApplicationContext()).addUser(userFromReg);
                            new FirebaseDatabaseDAO().addUserToFirebase(userFromReg);
                            SharedPreferences sp=getApplicationContext().getSharedPreferences("user",0);
                            SharedPreferences.Editor editor=sp.edit();
                            editor.putString("email",userFromReg.getEmail());
                            editor.putString("password",userFromReg.getPassword());
                            editor.putString("photo",userFromReg.getPhoto());
                            editor.putString("userName",userFromReg.getUserName());
                            editor.putInt("id",userFromReg.getUserId());
                            editor.putInt("isOnline",1);
                            Intent navigationDrawerIntent=new Intent(getApplicationContext(),NavigationDrawerActivity.class);
                            startActivity(navigationDrawerIntent);
                            finish();
                        }
                        else{
                            //found user in firebase
                            emailRegText.setError("Email Already Exist");
                        }
                    }
                });

            }
            else{
                //found user in local Strogae
                emailRegText.setError("Email Already Exist");
            }

        }


    }


    @Override
    public void onClick(View view) {
        //if the clicked button is choose
        if (view == imageView) {
            showFileChooser();
        }
        //if the clicked button is upload
        else if (view == signUpButton) {
            signUpMethod();
        }
    }

}
