package eg.gov.iti.jets.databasepkg;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import eg.gov.iti.jets.dtos.User;

/**
 * Created by Ali Alzantot on 07/03/2018.
 */

public class FirebaseDatabaseDAO {

    private int userId=0,noteId=0,tripId=0;

    public void getMaxuserIDFromFirebase(final MyCallback callback){

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("users");
        ref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        for (DataSnapshot userSnapshot: dataSnapshot.getChildren()) {
                            User singleUser = userSnapshot.getValue(User.class);
                            userId= Math.max(singleUser.getUserId(),userId);
                        }

                        callback.onMaxIdCallBack(userId);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

    }


    public void addUserToFirebase(User user){
        FirebaseDatabase database= FirebaseDatabase.getInstance();
        DatabaseReference myRef=database.getReference("users");
        myRef.child(Integer.toString(user.getUserId())).setValue(user);
    }


    public void getUserFromFirebase(final String userEmail, final String password, final MyCallback myCallback){

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("users");
        ref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        User user=null;
                        for (DataSnapshot userSnapshot: dataSnapshot.getChildren()) {
                            User singleUser = userSnapshot.getValue(User.class);
                            if(singleUser.getEmail().equals(userEmail)&&singleUser.getPassword().equals(password) ){
                                user=singleUser;
                                break;
                            }
                        }
                        myCallback.onGetUserCallBack(user);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        //handle databaseError
                    }
                });
    }

    public void getUserFromFirebaseByEmail(final String userEmail, final MyCallback myCallback){

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("users");
        ref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        User user=null;
                        for (DataSnapshot userSnapshot: dataSnapshot.getChildren()) {
                            User singleUser = userSnapshot.getValue(User.class);
                            if(singleUser.getEmail().equals(userEmail)){
                                user=singleUser;
                                break;
                            }
                        }
                        myCallback.onGetUserByEmailCallBack(user);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        //handle databaseError
                    }
                });
    }




}



