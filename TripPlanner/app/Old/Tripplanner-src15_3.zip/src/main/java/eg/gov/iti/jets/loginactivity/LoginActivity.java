package eg.gov.iti.jets.loginactivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

import eg.gov.iti.jets.databasepkg.DatabaseAdapter;
import eg.gov.iti.jets.databasepkg.FirebaseDatabaseDAO;
import eg.gov.iti.jets.databasepkg.MyCallback;
import eg.gov.iti.jets.dtos.User;

import eg.gov.iti.jets.signupactivity.SignupActivity;
import eg.gov.iti.jets.tripplanner.NavigationDrawerActivity;
import eg.gov.iti.jets.tripplanner.R;

public class LoginActivity extends AppCompatActivity {
    LoginButton loginButton;
    CallbackManager callbackManager;
    ProgressDialog progressDialog;
    User gettenUser, fbUser, loggedUser;
    Button signUpButton, signInButton;
    EditText signInEmail, signInPassword;
    private final String SHARED_PREF_USER = "user";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sp = getApplicationContext().getSharedPreferences(SHARED_PREF_USER, 0);
        if (sp.getInt("id", -1) != -1 && sp.getInt("isOnline", -1) != -1) {
            User user = User.getUser();
            user.setEmail(sp.getString("email", null));
            user.setPassword(sp.getString("password", null));
            user.setUserName(sp.getString("userName", null));
            user.setPhoto(sp.getString("photo", ""));
            user.setUserId(sp.getInt("id", 0));
            Intent navigationDrawerIntent = new Intent(getApplicationContext(), NavigationDrawerActivity.class);
            startActivity(navigationDrawerIntent);
            finish();
        }
        setContentView(R.layout.activity_login);
        callbackManager = CallbackManager.Factory.create();
        loginButton = (LoginButton)
                findViewById(R.id.login_button);
        loginButton.setReadPermissions(Arrays.asList("email,public_profile,user_birthday"));
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>()

        {
            @Override
            public void onSuccess(LoginResult loginResult) {
                progressDialog = new ProgressDialog(LoginActivity.this);
                progressDialog.setMessage("Retreiving data");
                progressDialog.show();


                GraphRequest request = GraphRequest.newMeRequest(
                        loginResult.getAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(
                                    JSONObject object,
                                    GraphResponse response) {
                                progressDialog.dismiss();
                                facebookLogin(object);

                            }
                        });


                Bundle parameters = new Bundle();
                parameters.putString("fields", "id,email,birthday,name,first_name,last_name");
                request.setParameters(parameters);
                request.executeAsync();


            }

            @Override
            public void onCancel() {
            }

            @Override
            public void onError(FacebookException exception) {
            }

        });

        signInPassword =

                findViewById(R.id.signInPassword);

        signInEmail =

                findViewById(R.id.signInEmail);

        signInButton =

                findViewById(R.id.signInButton);
        signInButton.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View view) {

                signInMethod();
            }
        });

        signUpButton =

                findViewById(R.id.signUpButton);
        signUpButton.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View view) {
                Intent signUpIntent = new Intent(getApplicationContext(), SignupActivity.class);
                startActivity(signUpIntent);
                finish();
            }
        });


    }

    private void facebookLogin(JSONObject jsonObject) {
        try {
            fbUser = User.getUser();
            fbUser.setPhoto("https://graph.facebook.com/" + jsonObject.getString("id") + "/picture?width=250&height=250");
            fbUser.setUserName(jsonObject.getString("name"));
            fbUser.setEmail(jsonObject.getString("email"));
            fbUser.setPassword("fbpassword");
            new FirebaseDatabaseDAO().getMaxuserIDFromFirebase(new MyCallback() {
                @Override
                public void onMaxIdCallBack(int max) {
                    DatabaseAdapter databaseAdapter = new DatabaseAdapter(getApplicationContext());
                    max = Math.max(databaseAdapter.getNewUserId(), max);
                    fbUser.setUserId(max + 1);
                    loggedUser = fbUser;
                }


                @Override
                public void onGetUserCallBack(User user) {
                }

                @Override
                public void onGetUserByEmailCallBack(User user) {
                }
            });

            gettenUser = new DatabaseAdapter(getApplicationContext()).retreiveUserByEmail(fbUser.getEmail());
            if (gettenUser == null) {
                new FirebaseDatabaseDAO().getUserFromFirebaseByEmail(fbUser.getEmail(), new MyCallback() {
                    @Override
                    public void onMaxIdCallBack(int max) {
                    }

                    @Override
                    public void onGetUserCallBack(User user) {
                    }

                    @Override
                    public void onGetUserByEmailCallBack(User user) {
                        gettenUser = user;
                        if (gettenUser == null) {
                            //not finding user in both loacl storgae or firebase
                            new DatabaseAdapter(getApplicationContext()).addUser(fbUser);
                            new FirebaseDatabaseDAO().addUserToFirebase(fbUser);
                            SharedPreferences sp = getApplicationContext().getSharedPreferences(SHARED_PREF_USER, 0);
                            SharedPreferences.Editor editor = sp.edit();
                            editor.putString("email", fbUser.getEmail());
                            editor.putString("password", fbUser.getPassword());
                            editor.putString("photo", fbUser.getPhoto());
                            editor.putString("userName", fbUser.getUserName());
                            editor.putInt("id", fbUser.getUserId());
                            editor.putInt("isOnline", 1);
                            editor.commit();
                            loginSuccess();
                        } else {
                            //found user in firebase
                            new DatabaseAdapter(getApplicationContext()).addUser(fbUser);
                            SharedPreferences sp = getApplicationContext().getSharedPreferences(SHARED_PREF_USER, 0);
                            SharedPreferences.Editor editor = sp.edit();
                            editor.putString("email", gettenUser.getEmail());
                            editor.putString("password", gettenUser.getPassword());
                            editor.putString("photo", gettenUser.getPhoto());
                            editor.putString("userName", gettenUser.getUserName());
                            editor.putInt("id", gettenUser.getUserId());
                            editor.putInt("isOnline", 1);
                            editor.commit();
                            loggedUser = gettenUser;
                            loginSuccess();
                        }
                    }
                });

            } else {
                //found user in local Strogae
                SharedPreferences sp = getApplicationContext().getSharedPreferences(SHARED_PREF_USER, 0);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("email", gettenUser.getEmail());
                editor.putString("password", gettenUser.getPassword());
                editor.putString("photo", gettenUser.getPhoto());
                editor.putString("userName", gettenUser.getUserName());
                editor.putInt("id", gettenUser.getUserId());
                editor.putInt("isOnline", 1);
                editor.commit();
                loggedUser = gettenUser;
                loginSuccess();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }


    public void signInMethod() {
        Boolean chkError = false;
        String email = signInEmail.getText().toString();
        String password = signInPassword.getText().toString();

        if (email.isEmpty()) {
            signInEmail.setError("please enter Your Email");
            chkError = true;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            signInEmail.setError("please enter a Valid Email");
            chkError = true;
        }

        if (password.isEmpty()) {
            signInPassword.setError("please enter your Password ");
            chkError = true;
        }

        if (chkError) {
            return;
        } else {
            gettenUser = new DatabaseAdapter(getApplicationContext()).retreiveUser(email, password);
            if (gettenUser == null) {
                new FirebaseDatabaseDAO().getUserFromFirebase(email, password, new MyCallback() {
                    @Override
                    public void onMaxIdCallBack(int max) {
                    }

                    @Override
                    public void onGetUserCallBack(User user) {
                        gettenUser = user;
                        if (gettenUser == null) {
                            //not finding user in both loacl storgae or firebase
                            signInEmail.setError("Please check your Email and password");
                            signInPassword.setError("Please check your Email and password");
                        } else {
                            //found user in firebase
                            SharedPreferences sp = getApplicationContext().getSharedPreferences(SHARED_PREF_USER, 0);
                            SharedPreferences.Editor editor = sp.edit();
                            new DatabaseAdapter(getApplicationContext()).addUser(gettenUser);
                            editor.putString("email", gettenUser.getEmail());
                            editor.putString("password", gettenUser.getPassword());
                            editor.putString("photo", gettenUser.getPhoto());
                            editor.putString("userName", gettenUser.getUserName());
                            editor.putInt("id", gettenUser.getUserId());
                            editor.putInt("isOnline", 1);
                            loggedUser = gettenUser;
                            editor.commit();
                            loginSuccess();
                        }
                    }

                    @Override
                    public void onGetUserByEmailCallBack(User user) {

                    }
                });

            } else {
                //found user in local Strogae
                SharedPreferences sp = getApplicationContext().getSharedPreferences(SHARED_PREF_USER, 0);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("email", gettenUser.getEmail());
                editor.putString("password", gettenUser.getPassword());
                editor.putString("photo", gettenUser.getPhoto());
                editor.putString("userName", gettenUser.getUserName());
                editor.putInt("id", gettenUser.getUserId());
                editor.putInt("isOnline", 1);
                editor.commit();
                loggedUser = gettenUser;
                loginSuccess();
            }

        }
    }

    private void loginSuccess() {

        User.getUser().setUserId(loggedUser.getUserId());
        User.getUser().setUserName(loggedUser.getUserName());
        User.getUser().setEmail(loggedUser.getEmail());
        User.getUser().setPassword(loggedUser.getPassword());
        User.getUser().setPhoto(loggedUser.getPhoto());
        Intent navigationDrawerIntent = new Intent(getApplicationContext(), NavigationDrawerActivity.class);
        startActivity(navigationDrawerIntent);
        finish();
    }

}


