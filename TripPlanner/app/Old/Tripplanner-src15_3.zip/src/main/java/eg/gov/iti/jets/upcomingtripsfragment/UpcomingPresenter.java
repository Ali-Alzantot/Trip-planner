package eg.gov.iti.jets.upcomingtripsfragment;

import android.content.Context;

import java.util.List;

import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.upcomingtripsfragment.upcomingfragmentinterfaces.*;


/**
 * Created by Usama on 7/3/2018.
 */

public class UpcomingPresenter implements PresenterInterface {

    private  ViewInterface view;
    private  ModelInterface model;

    public void setView(ViewInterface view) {
        this.view = view;
    }

    public UpcomingPresenter(Context context) {
        UpcomingModel modelDB = new UpcomingModel(context,this);
        this.model=modelDB;
    }

    @Override
    public void getTripListFromDB() {
        model.getAllTrips();
    }

    @Override
    public void addTripListToView(List<Trip> trip) {
        view.updateTripList(trip);

    }

    @Override
    public void deleteTripFromDB(Trip trip) {
        model.deleteTrip(trip);

    }

    @Override
    public void deleteTripFromView(Trip trip) {
        view.removeTripFromList(trip);
    }

    @Override
    public void addTripToView(Trip trip) {
        view.addTripToList(trip);
    }

    @Override
    public void updateTripInView(Trip trip) {
        view.updateTripInList(trip);
    }

    @Override
    public void updateTripInDB(Trip trip) {
        model.updateTrip(trip);
    }
}
