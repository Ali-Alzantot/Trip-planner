package eg.gov.iti.jets.createtripactivity;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import eg.gov.iti.jets.AlarmActivity.AlarmActivity;
import eg.gov.iti.jets.edittrip.EditTripActivity;
import eg.gov.iti.jets.tripplanner.R;
import eg.gov.iti.jets.helperclasses.MyDatePicker;
import eg.gov.iti.jets.helperclasses.MyTimePicker;
import eg.gov.iti.jets.helperinterfaces.MyDialogInterface;
import eg.gov.iti.jets.createtripactivity.interfaces.PresenterInterface;
import eg.gov.iti.jets.createtripactivity.interfaces.ViewInterface;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.dtos.User;
import eg.gov.iti.jets.tripplanner.NavigationDrawerActivity;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.GeoDataClient;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlacePhotoMetadata;
import com.google.android.gms.location.places.PlacePhotoMetadataBuffer;
import com.google.android.gms.location.places.PlacePhotoMetadataResponse;
import com.google.android.gms.location.places.PlacePhotoResponse;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.location.places.ui.SupportPlaceAutocompleteFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

public class CreateTripActivity extends AppCompatActivity implements ViewInterface, MyDialogInterface, Serializable {

    private Place from_place;
    private Place to_place;
    private User user;
    private Bitmap to_placeBitmap;

    private PresenterInterface presenterInterfaceRef;
    private MyDialogInterface myDialogInterface;
    private final int MY_External_Strorage_PERMISSION_CODE = 53;

    //components
    private EditText tripName_input;
    private SupportPlaceAutocompleteFragment place_autocomplete_fragment_from;
    private SupportPlaceAutocompleteFragment place_autocomplete_fragment_to;
    private EditText date_EditText;
    private EditText time_EditText;
    private String dateString;
    private String timeString;
    private Button createTripDone_btn;
    private byte[] imageBytes;
    private Trip trip;
    private int flagDonePressed;
    private SwitchCompat roundedTrip;
    private String isRoundedTripChecked = Trip.ONE_WAY;
    private ImageView tripImage;
    private static String GOOGLE_API_FRAG_FROM = "FROM_FRAGMENT";

    private static String GOOGLE_API_FRAG_TO = "TO_FRAGMENT";
    private String endPointPrev;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_trip);
        //intialize interfaces ref
        if(savedInstanceState!=null && savedInstanceState.getSerializable("presenterInterfaceRef")!=null)
        {
           presenterInterfaceRef=(PresenterInterface)savedInstanceState.getSerializable("presenterInterfaceRef");
        }
        else
        {
            presenterInterfaceRef = new Presenter(this, new Model(this));
        }


        myDialogInterface = this;
      //  tripImage = (ImageView) findViewById(R.id.create_trip_image);
        //get data from prev activity
        if(savedInstanceState!=null &&savedInstanceState.getParcelable("to_place")!=null)
        {
            to_place=(Place)savedInstanceState.getParcelable("to_place");
        }
        else if(getIntent().getParcelableExtra("to_place")!=null)
        {
            to_place = (Place) getIntent().getParcelableExtra("to_place");
        }

        if(savedInstanceState!=null && savedInstanceState.getByteArray("imageBytes")!=null)
        {
            imageBytes = savedInstanceState.getByteArray("imageBytes");
        }
        else if(getIntent().getByteArrayExtra("imageBytes")!=null)
        {
            imageBytes = getIntent().getByteArrayExtra("imageBytes");
        }
        if (imageBytes != null) {
            to_placeBitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            //tripImage.setImageBitmap(to_placeBitmap);
        }

        user = User.getUser();

        if(to_place!=null)
        {
            endPointPrev=to_place.getName().toString();
        }

        //intialize Btns
        createTripDone_btn = (Button) findViewById(R.id.createTripDone_btn);
        date_EditText = (EditText) findViewById(R.id.date_EditText);
        time_EditText = (EditText) findViewById(R.id.time_EditText);

        roundedTrip = (SwitchCompat) findViewById(R.id.roundedTrip);
        roundedTrip.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true) {
                    isRoundedTripChecked = Trip.GO_AND_RETURN;
                } else {
                    isRoundedTripChecked = Trip.ONE_WAY;
                }
            }
        });


        //place fragments
        place_autocomplete_fragment_from = new SupportPlaceAutocompleteFragment();
        place_autocomplete_fragment_to = new SupportPlaceAutocompleteFragment();
        FragmentTransaction tr = getSupportFragmentManager().beginTransaction();
        tr.replace(R.id.place_autocomplete_fragment_from, place_autocomplete_fragment_from, GOOGLE_API_FRAG_FROM);
        tr.replace(R.id.place_autocomplete_fragment_to, place_autocomplete_fragment_to, GOOGLE_API_FRAG_TO);
        tr.commit();


    }


    @Override
    protected void onStart() {
        super.onStart();

        //intialize dest
        tripName_input = (EditText) findViewById(R.id.tripName_input);

        if (to_place != null) {
            place_autocomplete_fragment_to.setText(to_place.getName());//1
            tripName_input.setText("Trip to " + to_place.getName().toString());
        }


        //place fragments liseners
        place_autocomplete_fragment_from.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                from_place = place;
            }

            @Override
            public void onError(Status status) {
                Toast.makeText(getApplicationContext(), "error in selecting place from", Toast.LENGTH_SHORT);
            }
        });

        place_autocomplete_fragment_to.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {

                to_place = place;
            }

            @Override
            public void onError(Status status) {
                Toast.makeText(getApplicationContext(), "Check your internet connection", Toast.LENGTH_SHORT);
            }
        });

        //btn listener
        createTripDone_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (flagDonePressed == 0) {

                    if ((dateString != null) && (timeString != null)) {
                        flagDonePressed = 1;

                        if (from_place == null && to_place != null)//fe to_place
                        {
                            trip = new Trip(user.getUserId(),
                                    tripName_input.getText().toString(),
                                    null,
                                    to_place.getName().toString(),
                                    timeString,
                                    dateString,
                                    isRoundedTripChecked,
                                    "1",
                                    Trip.UPCOMING,
                                   null, null,
                                    to_place.getLatLng().longitude, to_place.getLatLng().latitude, null);
                        }else if (from_place != null && to_place != null)//fe to_place
                        {
                            trip = new Trip(user.getUserId(),
                                    tripName_input.getText().toString(),
                                    from_place.getName().toString(),
                                    to_place.getName().toString(),
                                    timeString,
                                    dateString,
                                    isRoundedTripChecked,
                                    "1",
                                    Trip.UPCOMING,
                                    from_place.getLatLng().longitude, from_place.getLatLng().latitude,
                                    to_place.getLatLng().longitude, to_place.getLatLng().latitude, null);
                        }
                        if (trip != null) {

                            trip = presenterInterfaceRef.addTrip(trip);

                           //if (endPointPrev.equals(trip.getEndPoint())==false)//save pic l trip l gded
                           //{
                                if (ContextCompat.checkSelfPermission(CreateTripActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                    ActivityCompat.requestPermissions(CreateTripActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_External_Strorage_PERMISSION_CODE);
                                } else
                                {

                                    getPlacePicAndSave();
                                    String filePath = saveImage(Integer.toString(trip.getTripId()));//check hna lw fe mo4kla fl save yms7 l trip w y2ol ll user error
                                    trip.setPhoto(filePath);
                                    presenterInterfaceRef.updateTrip(trip);
                                    startAlert(trip);

                                }
                           /* }
                            else
                            {
                                String filePath = saveImage(Integer.toString(trip.getTripId()));//check hna lw fe mo4kla fl save yms7 l trip w y2ol ll user error
                                trip.setPhoto(filePath);
                                saveImage(filePath);
                                presenterInterfaceRef.updateTrip(trip);
                                startAlert(trip);
                            }*/


                          }
                         else {

                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Please enter trip date and time", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        date_EditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment dateDialogFragment = new MyDatePicker();
                Bundle bundle = new Bundle();
                bundle.putSerializable("myDialogInterface", (Serializable) myDialogInterface);
                dateDialogFragment.setArguments(bundle);
                dateDialogFragment.show(getSupportFragmentManager(), "dateDialogFragment");

            }
        });

        time_EditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timeDialogFragment = new MyTimePicker();
                Bundle bundle = new Bundle();
                bundle.putSerializable("myDialogInterface", (Serializable) myDialogInterface);
                timeDialogFragment.setArguments(bundle);
                timeDialogFragment.show(getSupportFragmentManager(), "timeDialogFragment");

            }
        });


    }


    @Override
    public void setDateString(int day, int month, int year) {
        this.dateString = day + "/" + month + "/" + year;
        date_EditText.setText(dateString);
    }

    @Override
    public void setTimeString(int hourOfDay, int min) {

        this.timeString = hourOfDay + ":" + min;
        time_EditText.setText(timeString);
    }

    public String saveImage(String fileName) {

        String filePath = null;
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), fileName);
            filePath = file.getAbsolutePath();
            new WriteImageToExternelStorage().execute(file);

        }
        return filePath;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_External_Strorage_PERMISSION_CODE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (endPointPrev.equals(trip.getEndPoint())==false)//save pic l trip l gded
                    {
                        getPlacePicAndSave();
                        String filePath = saveImage(Integer.toString(trip.getTripId()));//check hna lw fe mo4kla fl save yms7 l trip w y2ol ll user error
                        trip.setPhoto(filePath);
                        presenterInterfaceRef.updateTrip(trip);
                        startAlert(trip);
                    }
                    else
                    {
                        String filePath = saveImage(Integer.toString(trip.getTripId()));//check hna lw fe mo4kla fl save yms7 l trip w y2ol ll user error
                        trip.setPhoto(filePath);
                        saveImage(filePath);
                        presenterInterfaceRef.updateTrip(trip);
                    }
                }
                else
                {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
                break;


        }
    }

    public void gotoUpcommingActivity() {
        Toast.makeText(getApplicationContext(), "Trip added.", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(CreateTripActivity.this, NavigationDrawerActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }

    private class WriteImageToExternelStorage extends AsyncTask<File, Void, Void> {
        @Override
        protected Void doInBackground(File... files) {
            try (
                    FileOutputStream fos = new FileOutputStream(files[0]);) {
                    to_placeBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
             gotoUpcommingActivity();
        }
    }

    public void startAlert(Trip trip) {
        Intent intent = new Intent(this, AlarmActivity.class);
        intent.putExtra("user_id", trip.getUserId());
        intent.putExtra("trip_id", trip.getTripId());
        PendingIntent pendingIntent = PendingIntent.getActivity(this, Integer.parseInt(trip.getUserId().toString()+trip.getTripId().toString()),
                intent, PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        SimpleDateFormat sdformat = new SimpleDateFormat("hh:mm dd/MM/yyyy");
        Date date = null;
        try {
            date = sdformat.parse(trip.getStartTime() + " " + trip.getStartDate());
            alarmManager.set(AlarmManager.RTC_WAKEUP, date.getTime(), pendingIntent);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        alarmManager.set(AlarmManager.RTC_WAKEUP, date.getTime(), pendingIntent);
    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putSerializable("presenterInterfaceRef",presenterInterfaceRef);
        outState.putParcelable("to_place",(Parcelable)to_place);
        outState.putByteArray("imageBytes",imageBytes);
    }

    public void getPlacePicAndSave()
    {
        final GeoDataClient geoDataClient = Places.getGeoDataClient(CreateTripActivity.this, null);
        Task<PlacePhotoMetadataResponse> placePhotoMetadataResponseTask = geoDataClient.getPlacePhotos(to_place.getId());
        Task<PlacePhotoMetadataResponse> placePhotoMetadataResponseTask1 = placePhotoMetadataResponseTask.addOnCompleteListener(new OnCompleteListener<PlacePhotoMetadataResponse>() {
            @Override
            public void onComplete(@NonNull Task<PlacePhotoMetadataResponse> task) {
                PlacePhotoMetadataResponse placePhotoMetadataResponse = task.getResult();
                PlacePhotoMetadataBuffer placePhotoMetadataBuffer = placePhotoMetadataResponse.getPhotoMetadata();
                if ((placePhotoMetadataBuffer != null)) {
                    Iterator iterator = placePhotoMetadataBuffer.iterator();
                    if (iterator.hasNext()) {
                        PlacePhotoMetadata placePhotoMetadata = placePhotoMetadataBuffer.get(0);
                        if (placePhotoMetadata != null) {
                            Task<PlacePhotoResponse> placePhotoResponse = geoDataClient.getPhoto(placePhotoMetadata);
                            placePhotoResponse.addOnCompleteListener(new OnCompleteListener<PlacePhotoResponse>() {
                                @Override
                                public void onComplete(@NonNull Task<PlacePhotoResponse> task) {
                                    PlacePhotoResponse placePhotoResponse1 = task.getResult();
                                    to_placeBitmap = placePhotoResponse1.getBitmap();
                                    String filePath = saveImage(Integer.toString(trip.getTripId()));//check hna lw fe mo4kla fl save yms7 l trip w y2ol ll user error
                                    saveImage(filePath);
                                }
                            });
                        }
                    }
                }
            }
        });
    }

}

