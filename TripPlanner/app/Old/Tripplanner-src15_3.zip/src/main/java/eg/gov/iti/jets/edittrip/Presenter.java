package eg.gov.iti.jets.edittrip;



import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.edittrip.interfaces.ModelInterface;
import eg.gov.iti.jets.edittrip.interfaces.PresenterInterface;
import eg.gov.iti.jets.edittrip.interfaces.ViewInterface;

/**
 * Created by esraa on 3/5/2018.
 */

public class Presenter implements PresenterInterface {

    private ViewInterface viewInterfaceRef;
    private ModelInterface modelInterfaceRef;

    public Presenter(ViewInterface viewInterface, ModelInterface modelInterface) {
        this.viewInterfaceRef = viewInterface;
        this.modelInterfaceRef = modelInterface;
    }

     @Override
    public void updateTrip(Trip trip) {
         modelInterfaceRef.updateTrip(trip);
    }
}
