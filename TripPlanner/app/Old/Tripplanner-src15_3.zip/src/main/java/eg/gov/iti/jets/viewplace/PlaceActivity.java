package eg.gov.iti.jets.viewplace;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import eg.gov.iti.jets.createtripactivity.CreateTripActivity;
import eg.gov.iti.jets.tripplanner.R;
import eg.gov.iti.jets.dtos.User;
import eg.gov.iti.jets.viewplace.interfaces.ViewInterface;

import com.google.android.gms.location.places.GeoDataClient;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlacePhotoMetadata;
import com.google.android.gms.location.places.PlacePhotoMetadataBuffer;
import com.google.android.gms.location.places.PlacePhotoMetadataResponse;
import com.google.android.gms.location.places.PlacePhotoResponse;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.ByteArrayOutputStream;
import java.util.Iterator;

public class PlaceActivity extends AppCompatActivity implements ViewInterface {

    private Place place;
    private User user;
    private GeoDataClient geoDataClient;
    private TextView createTrip_btn;
    private TextView placeName_view;
    private TextView placeAddress;
    private TextView placeRating;
    private Bitmap to_placeBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewplace);

        //load data from bundle
        place = (Place) getIntent().getParcelableExtra("place");
        user = User.getUser();
        //View view= LayoutInflater.from(this).inflate(R.layout.activity_viewplace,null);
        createTrip_btn = (TextView) this.findViewById(R.id.createTrip_btn);
        if(createTrip_btn==null)
        Log.i("esraa","null");
        else
            Log.i("esraa",createTrip_btn.toString());

        placeName_view = (TextView) this.findViewById(R.id.placeName_view);
        placeAddress = (TextView) this.findViewById(R.id.placeAddress);
        placeRating = (TextView) this.findViewById(R.id.placeRating);


    }

    @Override
    protected void onStart() {
        super.onStart();

        placeName_view.setText(place.getName());
        placeAddress.setText(place.getAddress());
        placeRating.setText(Float.toString(place.getRating()));

        geoDataClient = Places.getGeoDataClient(this, null);
        Task<PlacePhotoMetadataResponse> placePhotoMetadataResponseTask = geoDataClient.getPlacePhotos(place.getId());
        placePhotoMetadataResponseTask.addOnCompleteListener(new OnCompleteListener<PlacePhotoMetadataResponse>() {
            @Override
            public void onComplete(@NonNull Task<PlacePhotoMetadataResponse> task) {

                PlacePhotoMetadataResponse placePhotoMetadataResponse = task.getResult();
                PlacePhotoMetadataBuffer placePhotoMetadataBuffer = placePhotoMetadataResponse.getPhotoMetadata();
                if ((placePhotoMetadataBuffer != null)) {
                    Iterator iterator = placePhotoMetadataBuffer.iterator();
                    if (iterator.hasNext()) {
                        PlacePhotoMetadata placePhotoMetadata = placePhotoMetadataBuffer.get(0);
                        if (placePhotoMetadata != null) {
                            Task<PlacePhotoResponse> placePhotoResponse = geoDataClient.getPhoto(placePhotoMetadata);
                            placePhotoResponse.addOnCompleteListener(new OnCompleteListener<PlacePhotoResponse>() {
                                @Override
                                public void onComplete(@NonNull Task<PlacePhotoResponse> task) {
                                    PlacePhotoResponse placePhotoResponse1 = task.getResult();
                                    ImageView img = (ImageView) findViewById(R.id.placeImage);
                                    to_placeBitmap = placePhotoResponse1.getBitmap();
                                    img.setImageBitmap(to_placeBitmap);
                                }
                            });
                        } else //put default img
                        {

                            Toast.makeText(getApplicationContext(), "no photos", Toast.LENGTH_SHORT);

                        }
                    }
                } else

                {
                    Toast.makeText(getApplicationContext(), "no photos22", Toast.LENGTH_SHORT);
                }

            }
        });

        //put place info

        placeName_view.setText(place.getName().toString());
        placeAddress.setText(place.getAddress().toString());
        placeRating.setText(Float.toString(place.getRating()));

        createTrip_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("esraa",createTrip_btn.toString());
                Intent intent = new Intent(PlaceActivity.this, CreateTripActivity.class);
                intent.putExtra("to_place", (Parcelable) place);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                to_placeBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                byte[] imageBytes = byteArrayOutputStream.toByteArray();
                intent.putExtra("imageBytes", imageBytes);
                startActivity(intent);
            }
        });

    }
}

