package eg.gov.iti.jets.AlarmActivity;

import android.content.Context;

import java.util.List;

import eg.gov.iti.jets.AlarmActivity.alarminterfaces.ModelInterface;
import eg.gov.iti.jets.AlarmActivity.alarminterfaces.PresenterInterface;
import eg.gov.iti.jets.AlarmActivity.alarminterfaces.ViewInterface;
import eg.gov.iti.jets.dtos.Trip;


/**
 * Created by Usama on 7/3/2018.
 */

public class AlarmPresenter implements PresenterInterface {

    private ViewInterface view;
    private ModelInterface model;

    public void setView(ViewInterface view) {
        this.view = view;
    }

    public AlarmPresenter(Context context) {
        AlarmModel modelDB = new AlarmModel(context,this);
        this.model=modelDB;
    }

    @Override
    public void getTripFromDB(int userID, int tripID) {
        model.getTrip(userID,tripID);

    }

    @Override
    public Trip getTripInstantly(int userID, int tripID) {
        return model.getTripInstantly(userID,tripID);
    }

    @Override
    public void updateTripInView(Trip trip) {
        view.addTripToView(trip);

    }

    @Override
    public void updateTripInDB(Trip trip) {
        model.updateTrip(trip);
    }
}
