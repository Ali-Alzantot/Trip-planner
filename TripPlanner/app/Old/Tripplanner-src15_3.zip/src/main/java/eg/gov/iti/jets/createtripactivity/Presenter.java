package eg.gov.iti.jets.createtripactivity;



import eg.gov.iti.jets.createtripactivity.interfaces.ModelInterface;
import eg.gov.iti.jets.createtripactivity.interfaces.PresenterInterface;
import eg.gov.iti.jets.createtripactivity.interfaces.ViewInterface;
import eg.gov.iti.jets.dtos.Trip;

/**
 * Created by esraa on 3/5/2018.
 */

public class Presenter implements PresenterInterface {

    private ViewInterface viewInterfaceRef;
    private ModelInterface modelInterfaceRef;

    public Presenter(ViewInterface viewInterface, ModelInterface modelInterface) {
        this.viewInterfaceRef = viewInterface;
        this.modelInterfaceRef = modelInterface;
    }

    @Override
    public Trip addTrip(Trip trip) {
         return modelInterfaceRef.addTrip(trip);
    }

    @Override
    public void updateTrip(Trip trip) {
         modelInterfaceRef.updateTrip(trip);
    }
}
