package eg.gov.iti.jets.AlarmActivity;

import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

import eg.gov.iti.jets.AlarmActivity.alarminterfaces.ModelInterface;
import eg.gov.iti.jets.AlarmActivity.alarminterfaces.PresenterInterface;
import eg.gov.iti.jets.databasepkg.DatabaseAdapter;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.dtos.User;

/**
 * Created by Usama on 7/3/2018.
 */

public class AlarmModel implements ModelInterface {
    private PresenterInterface presenter;
    private DatabaseAdapter dbAdapter;


    public AlarmModel(Context context, PresenterInterface upcommingPresenter) {
        dbAdapter = new DatabaseAdapter(context);
        presenter = upcommingPresenter;
    }


    @Override
    public void getTrip(int userID, int tripID) {
        Trip trip = new Trip();
        trip.setUserId(userID);
        trip.setTripId(tripID);
        new getTripTask().execute(trip);
    }

    @Override
    public Trip getTripInstantly(int userID, int tripID) {
        return dbAdapter.getTripById(tripID,userID);
    }

    @Override
    public void updateTrip(Trip trip) {
        new updateTripTask().execute(trip);
    }


    private class getTripTask extends AsyncTask<Trip, Void, Trip> {
        @Override
        protected Trip doInBackground(Trip... trips) {
            return dbAdapter.getTripById(trips[0].getTripId(), trips[0].getUserId());
        }

        @Override
        protected void onPostExecute(Trip trip) {
            if (trip != null) {
                presenter.updateTripInView(trip);
            }
        }
    }

    private class updateTripTask extends AsyncTask<Trip, Void, Void> {

        @Override
        protected Void doInBackground(Trip... trips) {
            dbAdapter.updateTrip(trips[0]);
            return null;
        }
    }


}
