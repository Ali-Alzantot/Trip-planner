

package eg.gov.iti.jets.AlarmActivity.alarminterfaces;

import java.io.Serializable;

import eg.gov.iti.jets.dtos.Trip;

/**
 * Created by Usama on 7/3/2018.
 */

public interface ModelInterface extends Serializable {
    public void getTrip(int userID,int tripID);
    public Trip getTripInstantly(int userID,int tripID);
    public void updateTrip(Trip trip);
}
