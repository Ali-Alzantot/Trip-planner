package eg.gov.iti.jets.databasepkg;

import eg.gov.iti.jets.dtos.User;

/**
 * Created by Ali Alzantot on 08/03/2018.
 */

public interface MyCallback {
    void onMaxIdCallBack(int max);
    void onGetUserCallBack(User user);
    void onGetUserByEmailCallBack(User user);
}
