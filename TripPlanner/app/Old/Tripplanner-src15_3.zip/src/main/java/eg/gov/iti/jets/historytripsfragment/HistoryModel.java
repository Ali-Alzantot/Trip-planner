package eg.gov.iti.jets.historytripsfragment;

import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

import eg.gov.iti.jets.databasepkg.DatabaseAdapter;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.dtos.User;
import eg.gov.iti.jets.historytripsfragment.historyfragmentinterfaces.ModelInterface;
import eg.gov.iti.jets.historytripsfragment.historyfragmentinterfaces.PresenterInterface;

/**
 * Created by Usama on 7/3/2018.
 */

public class HistoryModel implements ModelInterface {
    private PresenterInterface presenter;
    private DatabaseAdapter dbAdapter;


    public HistoryModel(Context context, PresenterInterface presenter) {
        dbAdapter = new DatabaseAdapter(context);
        this.presenter = presenter;
    }

    @Override
    public void getAllHistoryTrips() {
        new getAllTripsTask().execute(User.getUser());
    }

    @Override
    public void deleteTrip(Trip trip) {
        new deleteTripTask().execute(trip);
    }

    @Override
    public void updateTrip(Trip trip) {
        new updateTripTask().execute(trip);
    }


    private class getAllTripsTask extends AsyncTask<User, Void, List<Trip>> {
        @Override
        protected List<Trip> doInBackground(User... users) {
            return dbAdapter.getAllHistoryTrips(users[0]);
        }

        @Override
        protected void onPostExecute(List<Trip> trips) {
            if (trips != null&& trips.size()>0) {
                presenter.addTripListToView(trips);
            }
        }
    }

    private class deleteTripTask extends AsyncTask<Trip, Void, Trip> {

        @Override
        protected Trip doInBackground(Trip... trips) {
            dbAdapter.deleteTrip(trips[0]);
            return trips[0];
        }

        @Override
        protected void onPostExecute(Trip trip) {
            presenter.deleteTripFromView(trip);
        }
    }

    private class updateTripTask extends AsyncTask<Trip, Void, Trip> {

        @Override
        protected Trip doInBackground(Trip... trips) {
            dbAdapter.updateTrip(trips[0]);
            return trips[0];
        }

        @Override
        protected void onPostExecute(Trip trip) {
            presenter.updateTripInView(trip);
        }
    }
}
