package eg.gov.iti.jets.profileactivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import eg.gov.iti.jets.databasepkg.*;
import eg.gov.iti.jets.dtos.User;
import eg.gov.iti.jets.tripplanner.R;

import static com.facebook.FacebookSdk.getApplicationContext;


public class ProfileFragment extends Fragment implements View.OnClickListener{

    Button editProfileButton;
    EditText emailEditText,oldPasswordEditText,userNameEditText,newPasswordEditText;
    String email,oldPassword,newPassword,userName;
    View view;
    SharedPreferences sp;
    public ProfileFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_profile, container, false);
        editProfileButton=view.findViewById(R.id.editProfileButton);
        editProfileButton.setOnClickListener(this);
        emailEditText=view.findViewById(R.id.emailEditText);
        oldPasswordEditText=view.findViewById(R.id.oldPasswordEditText);
        userNameEditText=view.findViewById(R.id.userNameEditText);
        newPasswordEditText=view.findViewById(R.id.newPasswordEditText);
        sp=getActivity().getSharedPreferences("user",0);
        emailEditText.setText(sp.getString("email",""));
        userNameEditText.setText(sp.getString("userName",""));

        return view;
    }



    public void editProfile(){

        boolean chkError=false;
        userName=userNameEditText.getText().toString();
        email=emailEditText.getText().toString();
        oldPassword=oldPasswordEditText.getText().toString();
        newPassword=newPasswordEditText.getText().toString();

        if(userName.isEmpty()){
            userNameEditText.setError("please enter Your user Name");
            chkError=true;
        }


        if(email.isEmpty()){
            emailEditText.setError("please enter Your Email");
            chkError=true;
        }

        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            emailEditText.setError("please enter a Valid Email");
            chkError=true;
        }

        if(oldPassword.isEmpty() || !oldPassword.equals(sp.getString("password",""))){
            oldPasswordEditText.setError("Worng Password ");
            chkError=true;
        }

        if((newPassword.isEmpty() || newPassword.length()<6)){
            newPasswordEditText.setError("please enter Password not less than 6 chars");
            chkError=true;
        }

        if(chkError)
            return;
        else {
            User user=User.getUser();
            user.setEmail(email);
            user.setPassword(newPassword);
            user.setUserName(userName);
            user.setPhoto(sp.getString("photo","no photo"));
            user.setUserId(sp.getInt("id",-1));
            new DatabaseAdapter(getApplicationContext()).updateUser(user);
            new FirebaseDatabaseDAO().addUserToFirebase(user);
        }


    }





    @Override
    public void onClick(View view) {

        //if the clicked button is edit
        if (view == editProfileButton) {
            editProfile();
        }
    }
}
