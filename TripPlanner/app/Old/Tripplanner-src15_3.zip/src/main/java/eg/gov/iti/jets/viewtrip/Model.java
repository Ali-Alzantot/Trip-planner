package eg.gov.iti.jets.viewtrip;

import android.content.Context;
import android.os.AsyncTask;

import eg.gov.iti.jets.databasepkg.DatabaseAdapter;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.upcomingtripsfragment.UpcomingModel;
import eg.gov.iti.jets.upcomingtripsfragment.upcomingfragmentinterfaces.PresenterInterface;
import eg.gov.iti.jets.viewtrip.interfaces.ModelInterface;

/**
 * Created by esraa on 3/5/2018.
 */

public class Model implements ModelInterface {

    private DatabaseAdapter dbAdapter;

    public Model(Context context) {
        dbAdapter = new DatabaseAdapter(context);
      }
    @Override
    public void deleteTrip(Trip trip)
    {
        new deleteTripTask().execute(trip);
    }

    private class deleteTripTask extends AsyncTask<Trip, Void, Trip> {
        @Override
        protected Trip doInBackground(Trip... trips) {
            dbAdapter.deleteTrip(trips[0]);
            return trips[0];
        }
    }
}
