package eg.gov.iti.jets.viewtrip;

import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.viewtrip.interfaces.ModelInterface;
import eg.gov.iti.jets.viewtrip.interfaces.PresenterInterface;
import eg.gov.iti.jets.viewtrip.interfaces.ViewInterface;

/**
 * Created by esraa on 3/5/2018.
 */

public class Presenter implements PresenterInterface {

    private ViewInterface viewInterface;
    private ModelInterface modelInterface;

    public Presenter(ViewInterface viewInterface, ModelInterface modelInterface) {
        this.viewInterface = viewInterface;
        this.modelInterface = modelInterface;
    }

    @Override
    public void deleteTripFromDB(Trip trip) {
        modelInterface.deleteTrip(trip);

    }


}
