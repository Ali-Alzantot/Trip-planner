package eg.gov.iti.jets.viewtrip;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.places.GeoDataClient;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlacePhotoMetadata;
import com.google.android.gms.location.places.PlacePhotoMetadataBuffer;
import com.google.android.gms.location.places.PlacePhotoMetadataResponse;
import com.google.android.gms.location.places.PlacePhotoResponse;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;

import eg.gov.iti.jets.createtripactivity.CreateTripActivity;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.dtos.User;
import eg.gov.iti.jets.edittrip.EditTripActivity;
import eg.gov.iti.jets.tripplanner.NavigationDrawerActivity;
import eg.gov.iti.jets.tripplanner.R;
import eg.gov.iti.jets.viewplace.PlaceActivity;
import eg.gov.iti.jets.viewtrip.interfaces.PresenterInterface;
import eg.gov.iti.jets.viewtrip.interfaces.ViewInterface;

public class ViewTripActivity extends AppCompatActivity implements ViewInterface {

    private ImageView placeImage;
    private TextView placeName_view;
    private ImageView upcoming_goButton;
    private ImageView upcoming_three_dots;
    private TextView upcoming_tripStatus;
    private TextView upcoming_start_point;
    private TextView upcoming_end_point;
    private TextView upcoming_date_time;



    private Trip trip;
    private PresenterInterface presenterInterface;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewtrip);


        if(savedInstanceState!=null &&savedInstanceState.getSerializable("presenterInterface")!=null)
        {
            presenterInterface=(PresenterInterface)savedInstanceState.getSerializable("presenterInterface");
        }
        else
        {
            presenterInterface=new Presenter(this,new Model(this));
        }

        //load data from bundle
        if((Trip)getIntent().getSerializableExtra("trip")!=null)
        {
            trip=(Trip)getIntent().getSerializableExtra("trip");
        }
        else
        {
            trip=(Trip)savedInstanceState.getSerializable("trip");
        }

        //get ref of objs
        placeImage=(ImageView)findViewById(R.id.placeImage);
        placeName_view = (TextView) findViewById(R.id.placeName_view);
        upcoming_goButton=(ImageView)findViewById(R.id.upcoming_goButton);
        upcoming_three_dots=(ImageView)findViewById(R.id.upcoming_three_dots);
        upcoming_tripStatus = (TextView) findViewById(R.id.upcoming_tripStatus);
        upcoming_start_point = (TextView) findViewById(R.id.upcoming_start_point);
        upcoming_end_point = (TextView) findViewById(R.id.upcoming_end_point);
        upcoming_date_time = (TextView) findViewById(R.id.upcoming_date_time);



        upcoming_goButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //open map
            }
        });

        upcoming_three_dots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        if(trip!=null)
        {
            placeName_view.setText(trip.getTripName());
            upcoming_tripStatus.setText(trip.getStatus());
            upcoming_start_point.setText(trip.getStartPoint());
            upcoming_end_point.setText(trip.getEndPoint());
            upcoming_date_time.setText(trip.getStartDate()+" at "+trip.getStartTime());
        }

        if (trip.getPhoto() != null && !trip.getPhoto().trim().equals(""))
        {
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
            {
                File file = new File(trip.getPhoto());
                if (file.exists()) {
                    new ImageThread().execute(file);
                }
            } else
                {
                placeImage.setImageResource(R.drawable.default_trip_photo);
                }
        }


    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putSerializable("trip",trip);
        outState.putSerializable("presenterInterface",(Serializable)presenterInterface);
    }


    private class ImageThread extends AsyncTask<File,Void,Bitmap> {
        @Override
    protected Bitmap doInBackground(File...files) {
        Bitmap photo = null;
        try
        {
            FileInputStream fis = new FileInputStream(files[0]);
            photo = BitmapFactory.decodeStream(fis);

        } catch (IOException e)
        {
            e.printStackTrace();
        }
        return photo;

    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
       if(bitmap!=null)
       {
           placeImage.setImageBitmap(bitmap);
       }
       else
       {
           placeImage.setImageResource(R.drawable.default_trip_photo);
       }


    }
}


    public void showPopupMenu()
    {
        //3DOTS menu
        View threeDotsView=(ImageView)findViewById(R.id.upcoming_three_dots);
        PopupMenu popupMenu=new PopupMenu(this,threeDotsView);
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.upcoming_edit_trip_option:
                        Intent intent= new Intent(ViewTripActivity.this,EditTripActivity.class);
                        intent.putExtra("trip",trip);
                        ViewTripActivity.this.startActivity(intent);
                        return true;

                    // delete option
                    case R.id.upcoming_delete_trip_option:

                        AlertDialog.Builder builder = new AlertDialog.Builder(ViewTripActivity.this);
                        builder.setTitle(" Delete Trip ").setMessage(" Do you want to delete " + trip.getTripName() + " trip ?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                presenterInterface.deleteTripFromDB(trip);
                                Intent intent= new Intent(ViewTripActivity.this,NavigationDrawerActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                ViewTripActivity.this.startActivity(intent);

                            }
                        })
                                .setNegativeButton("No", null).show();

                        return true;
                    default:
                        return false;
                }
            }
        });
        MenuInflater menuInflater=popupMenu.getMenuInflater();
        menuInflater.inflate(R.menu.upcoming_three_dots_menu,popupMenu.getMenu());
        popupMenu.show();
    }

}

