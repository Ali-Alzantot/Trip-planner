package eg.gov.iti.jets.profileactivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import eg.gov.iti.jets.dtos.User;

import eg.gov.iti.jets.tripplanner.R;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        User user= (User) getIntent().getSerializableExtra("user");
        SharedPreferences sp=getSharedPreferences("user",0);
        int isOnline=sp.getInt("isOnline",-1);

    }
}
