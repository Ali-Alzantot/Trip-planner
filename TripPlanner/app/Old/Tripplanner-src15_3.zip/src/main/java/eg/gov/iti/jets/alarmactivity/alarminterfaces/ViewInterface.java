
package eg.gov.iti.jets.AlarmActivity.alarminterfaces;


import java.io.Serializable;
import java.util.List;

import eg.gov.iti.jets.dtos.Trip;

/**
 * Created by Usama on 7/3/2018.
 */

public interface ViewInterface extends Serializable{
    public void addTripToView(Trip trip);
}
