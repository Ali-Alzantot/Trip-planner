package eg.gov.iti.jets.dtos;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/*
 @author Usama
 */
@SuppressWarnings("serial")
public class Note implements Serializable {
    @SerializedName("noteId")
    private Integer noteId;
    @SerializedName("tripId")
    private Integer tripId;
    @SerializedName("userId")
    private Integer userId;
    @SerializedName("note")
    private String note;
    @SerializedName("status")
    private String status;

    public Note() {
    }

    public Note(Integer tripId, Integer userId, String note, String status) {
        this.tripId = tripId;
        this.userId = userId;
        this.note = note;
        this.status = status;
    }

    public Integer getNoteId() {
        return noteId;
    }

    public void setNoteId(Integer noteId) {
        this.noteId = noteId;
    }

    public Integer getTripId() {
        return tripId;
    }

    public void setTripId(Integer tripId) {
        this.tripId = tripId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
