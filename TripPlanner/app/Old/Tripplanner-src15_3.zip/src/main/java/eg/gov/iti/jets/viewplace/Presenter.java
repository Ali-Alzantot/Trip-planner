package eg.gov.iti.jets.viewplace;

import eg.gov.iti.jets.viewplace.interfaces.ModelInterface;
import eg.gov.iti.jets.viewplace.interfaces.PresenterInterface;
import eg.gov.iti.jets.viewplace.interfaces.ViewInterface;

/**
 * Created by esraa on 3/5/2018.
 */

public class Presenter implements PresenterInterface {

    private ViewInterface viewInterface;
    private ModelInterface modelInterface;

    public Presenter(ViewInterface viewInterface, ModelInterface modelInterface) {
        this.viewInterface = viewInterface;
        this.modelInterface = modelInterface;
    }

}
