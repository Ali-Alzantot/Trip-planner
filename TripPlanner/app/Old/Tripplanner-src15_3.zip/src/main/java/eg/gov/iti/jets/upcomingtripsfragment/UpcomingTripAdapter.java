package eg.gov.iti.jets.upcomingtripsfragment;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import eg.gov.iti.jets.AlarmActivity.AlarmActivity;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.edittrip.EditTripActivity;
import eg.gov.iti.jets.tripplanner.R;
import eg.gov.iti.jets.upcomingtripsfragment.upcomingfragmentinterfaces.PresenterInterface;
import eg.gov.iti.jets.viewtrip.ViewTripActivity;

/**
 * Created by USAMA on 07/03/2018.
 */

public class UpcomingTripAdapter extends RecyclerView.Adapter<UpcomingTripAdapter.TripViewHolder> implements Serializable {


    private List<Trip> tripList;
    private Context context;
    private transient PresenterInterface presenter;

    public UpcomingTripAdapter(Context Context, List<Trip> tripList, PresenterInterface presenter) {
        this.context = Context;
        this.tripList = tripList;
        this.presenter = presenter;
    }

    @Override
    public TripViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.upcoming_trip_card, parent, false);
        return new TripViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final TripViewHolder holder, int position) {
        final Trip trip = tripList.get(position);
        Bitmap photo = null;
        holder.getCardView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToViewTripActivity(trip);
            }
        });
        holder.getTripPhoto().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToViewTripActivity(trip);
            }
        });
        holder.getTripName().setText(trip.getTripName());
//        holder.getStartPoint().setText(trip.getStartPoint());//esraaaaaaa
//        holder.getEndPoint().setText(trip.getEndPoint());
        holder.getSchedule().setText(trip.getStartDate() + "  At  " + trip.getStartTime());
        holder.getStatus().setText(trip.getStatus());
        switch (trip.getStatus()) {
            case Trip.UPCOMING:
                holder.getStatus().setTextColor(Color.BLUE);
                break;
            case Trip.ONGOING:
                holder.getStatus().setTextColor(Color.GREEN);
                break;

        }
        holder.getStatus().setText(trip.getStatus());
        if (trip.getPhoto() != null && !trip.getPhoto().trim().equals("")) {
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                File file = new File(trip.getPhoto());
                if (file.exists()) {
                    try (
                            FileInputStream fis = new FileInputStream(file);) {
                        photo = BitmapFactory.decodeStream(fis);

                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        if (photo != null) {
                            holder.getTripPhoto().setImageBitmap(photo);
                        } else {
                            holder.getTripPhoto().setImageResource(R.drawable.default_trip_photo);
                        }
                    }
                }
            } else {
                holder.getTripPhoto().setImageResource(R.drawable.default_trip_photo);
            }
        }


        holder.getThreeDotMenu().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopupMenu(holder.getThreeDotMenu(), trip);
            }
        });
        holder.getGoButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!trip.getStatus().equals(Trip.ONGOING)) {
                    trip.setStatus(Trip.ONGOING);
                    presenter.updateTripInDB(trip);
                }
                showDirection(trip);
            }
        });

    }

    private void goToViewTripActivity(Trip trip) {//esraaaaaa
        Intent intent = new Intent(context, ViewTripActivity.class);
        intent.putExtra("trip", (Serializable)trip);
        context.startActivity(intent);

    }

    private void showDirection(Trip trip) {
        Uri gmmIntentUri = Uri.parse("google.navigation:q=" + trip.getEndLatitude() + "," + trip.getEndLongitude() + "&travelmode=driving");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        if (mapIntent.resolveActivity(context.getPackageManager()) != null) {
            context.startActivity(mapIntent);
        } else {
            Toast.makeText(context, "Please install a maps application", Toast.LENGTH_SHORT).show();
        }

        cancelAlarm(trip.getUserId(), trip.getTripId());
    }

    private void cancelAlarm(Integer userId, Integer tripId) {
        Intent intent = new Intent(context, AlarmActivity.class);
        intent.putExtra("user_id", userId);
        intent.putExtra("trip_id", tripId);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, Integer.parseInt(userId.toString() + tripId.toString()),
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        pendingIntent.cancel();
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pendingIntent);
    }

    public void addItem(Trip trip) {
        tripList.add(trip);
        int position = tripList.indexOf(trip);
        notifyItemChanged(position);
        notifyItemRangeChanged(position, tripList.size());
    }

    public int deleteItem(Trip trip) {
        int position = tripList.indexOf(trip);
        tripList.remove(trip);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, tripList.size());
        return position;

    }

    public void updateItem(Trip trip) {
        int position = tripList.indexOf(trip);
        tripList.remove(trip);
        tripList.add(position, trip);
        notifyItemChanged(position);
    }

    public void updateList(List<Trip> trips) {
        tripList = trips;
        notifyItemRangeChanged(0, tripList.size());
        notifyDataSetChanged();
    }

    /**
     * Showing popup menu when tapping on 3 dots image
     */
    private void showPopupMenu(View view, final Trip trip) {
        // inflate menu
        PopupMenu popup = new PopupMenu(context, view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.upcoming_three_dots_menu, popup.getMenu());
        // 3 dot menu
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {//esraaa
                    // edit option
                    case R.id.upcoming_edit_trip_option:
                        Toast.makeText(context, "Edit Trip" + trip.getTripId(), Toast.LENGTH_SHORT).show();
                        Intent intent= new Intent(context,EditTripActivity.class);
                        intent.putExtra("trip",trip);
                        context.startActivity(intent);
                        return true;

                    // delete option
                    case R.id.upcoming_delete_trip_option:

                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle(" Delete Trip ").setMessage(" Do you want to delete " + trip.getTripName() + " trip ?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                presenter.deleteTripFromDB(trip);
                            }
                        })
                                .setNegativeButton("No", null).show();

                        return true;
                    default:
                }
                return false;
            }
        });
        popup.show();
    }


    @Override
    public int getItemCount() {
        return tripList.size();
    }


    // View Holder
    public class TripViewHolder extends RecyclerView.ViewHolder {//esraaaaa
        private ImageView tripPhoto, threeDotMenu, goButton;
        // private TextView tripName, startPoint, endPoint, schedule, status;
        private TextView tripName, schedule, status;
        private CardView cardView;

        public TripViewHolder(View view) {
            super(view);
            cardView = (CardView) view.findViewById(R.id.upcoming_card_view);
            tripPhoto = (ImageView) view.findViewById(R.id.upcoming_trip_photo);
            threeDotMenu = (ImageView) view.findViewById(R.id.upcoming_three_dots);
            goButton = (ImageView) view.findViewById(R.id.upcoming_goButton);
            tripName = (TextView) view.findViewById(R.id.upcoming_trip_title);
//            startPoint = (TextView) view.findViewById(R.id.upcoming_start_point);
//            endPoint = (TextView) view.findViewById(R.id.upcoming_end_point);
            schedule = (TextView) view.findViewById(R.id.upcoming_date_time);
            status = (TextView) view.findViewById(R.id.upcoming_tripStatus);
        }

        public CardView getCardView() {
            return cardView;
        }

        public ImageView getTripPhoto() {
            return tripPhoto;
        }

        public ImageView getThreeDotMenu() {
            return threeDotMenu;
        }

        public ImageView getGoButton() {
            return goButton;
        }

        public TextView getTripName() {
            return tripName;
        }

        //        public TextView getStartPoint() {
//            return startPoint;
//        }
//
//        public TextView getEndPoint() {
//            return endPoint;
//        }


        public TextView getSchedule() {
            return schedule;
        }

        public TextView getStatus() {
            return status;
        }

    }


}
