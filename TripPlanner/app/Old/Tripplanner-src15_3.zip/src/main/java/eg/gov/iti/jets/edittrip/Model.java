package eg.gov.iti.jets.edittrip;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import eg.gov.iti.jets.databasepkg.DatabaseAdapter;
import eg.gov.iti.jets.dtos.Trip;
import eg.gov.iti.jets.edittrip.interfaces.ModelInterface;

/**
 * Created by esraa on 3/5/2018.
 */

public class Model implements ModelInterface {

    Context context;
    DatabaseAdapter databaseAdapter;

    public Model(Context context) {
        this.context = context;
        databaseAdapter = new DatabaseAdapter(context);
    }


    @Override
    public void updateTrip(Trip trip) {

        new UpdateTripTask().execute(trip);
    }

    private class UpdateTripTask extends AsyncTask<Trip, Void, Void> {
        @Override
        protected Void doInBackground(Trip... trips) {
            databaseAdapter.updateTrip(trips[0]);
            Log.i("esraa","update"+trips[0].getTripName());
            return null;
        }
    }

}
