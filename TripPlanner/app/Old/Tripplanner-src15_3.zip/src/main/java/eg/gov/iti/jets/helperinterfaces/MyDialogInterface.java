package eg.gov.iti.jets.helperinterfaces;

/**
 * Created by esraa on 3/8/2018.
 */

public interface MyDialogInterface {

    public void setDateString(int day, int month, int year);
    public void setTimeString(int hourOfDay, int min);

}
